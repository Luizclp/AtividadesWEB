<html>
<head>
<title>Relatório de Funcionarios</title>
<?php include ('config.php');  ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="funcionarioslst.php?botao=gravar" method="post" name="form1">
<table width="95%" border="1" align="center">
  <tr>
    <td colspan=5 align="center">Relatório de Funcionarios</td>
  </tr>
  <tr>
    <td width="18%" align="right">Nome:</td>
    <td width="26%"><input type="text" name="nome"  /></td>
    <td width="17%" align="right">Data de Nascimento:</td>
    <td width="18%"><input type="text" name="data_ncto" size="3" /></td>
    <td width="17%" align="right">Salario:</td>
    <td width="18%"><input type="text" name="salario" size="3" /></td>
    <td width="21%"><input type="submit" name="botao" value="Gerar" /></td>
  </tr>
</table>
</form>

<?php if (@$_POST['botao'] == "Gerar") { ?>

<table width="95%" border="1" align="center">
  <tr bgcolor="#9999FF">
    <th width="5%">C&oacute;d</th>
    <th width="30%">Nome</th>
    <th width="15%">Data de Nascimento</th>
    <th width="12%">Salario</th>
  </tr>

<?php

  $mes_atual = date("m");

	$nome = $_POST['nome'];
	$data_ncto = $_POST['data_ncto'];
	

	$query = "SELECT *
			  FROM tb_funcionario 
			  WHERE id > 0 ";
	$query .= ($nome ? " AND nome LIKE '%$nome%' " : "");
	$query .= ($data_ncto ? " AND idade = '$data_ncto' " : "");
	$query .= " ORDER by nome ASC";
        $result = mysqli_query($mysqli, $query);

	while ($coluna=mysqli_fetch_array($result)) 
	{
		
	?>
    
    <tr>
      <th width="5%"><?php echo $coluna['id']; ?></th>
      <th width="5%"><?php echo $coluna['nome']; ?></th>
      <th width="30%"><?php echo $coluna['data_ncto']; ?></th>
      <th width="15%"><?php echo $coluna['salario']; ?></th>
  	</tr>

    <?php
	
	} // fim while
?>
</table>
<?php	
}
?>

<a href="index.html" >Home </a>

</body>