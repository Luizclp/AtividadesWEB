<html>

<head>
<title>Cadastro de Clientes</title>

<?php include ('config.php');  ?>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="funcionario.php" method="post" name="cliente">
<table width="200" border="1">
  <tr>
    <td colspan="2">Cadastro de Funcionario</td>
  </tr>
  <tr>
    <td>Nome:</td>
    <td><input type="text" name="nome" ></td>
  </tr>
  <tr>
    <td>Data de Nascimento:</td>
    <td><input type="Date" name="data_ncto" ></td>
  </tr>
  <tr>
    <td>Salário:</td>
    <td><input type="number" name="salario">
    </td>
  </tr>
  <tr>
    <td colspan="2" align="right"><input type="submit" value="Gravar" name="botao"></td>
    </tr>	
</table>
</form>

<?php
if (@$_POST['botao'] == "Gravar") 
	{
		
		$nome = $_POST['nome'];
		$data_ncto = $_POST['data_ncto'];
		$salario = $_POST['salario'];

		$insere = "INSERT into tb_funcionario (nome, data_ncto, salario) 
    VALUES ('$nome', '$data_ncto', '$salario')";
		mysqli_query($mysqli, $insere) or die ("Não foi possivel inserir os dados");
	}

?>

<a href="index.html" >Home </a>
</body>
</html>