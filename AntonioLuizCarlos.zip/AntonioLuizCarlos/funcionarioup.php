<html>
<head>
<title>Alteração de Funcionario</title>
<?php include ('config.php'); ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>

<body>
<form action="funcionarioup.php?botao=gravar" method="post" name="form1">
<table width="95%" border="1" align="center">
  <tr>
    <td colspan="5" align="center">Alteração de Funcionario</td>
  </tr>
  <tr>
    <td width="18%" align="right">id:</td>
    <td width="26%"><input type="number" name="id" /></td>

    <td width="18%" align="right">Nome:</td>
    <td width="26%"><input type="text" name="nome" /></td>

    <td width="18%" align="right">data_ncto:</td>
    <td width="26%"><input type="date" name="data_ncto" /></td>

    <td width="18%" align="right">salario:</td>
    <td width="26%"><input type="number" name="salario" /></td>

    <td width="21%"><input type="submit" name="botao" value="Alterar" /></td>
  </tr>
</table>
</form>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['botao']) && $_POST['botao'] == "Alterar") {
    $id = intval($_POST['id']);
    $nome = mysqli_real_escape_string($mysqli, $_POST['nome']);
    $data_ncto = mysqli_real_escape_string($mysqli, $_POST['data_ncto']);
    $salario = mysqli_real_escape_string($mysqli, $_POST['salario']);

    // Validação básica
    if ($id > 0) {
        // Atualiza a idade se for fornecida
        if ($salario > 0) {
            mysqli_query($mysqli, "UPDATE tb_funcionario SET salario='$salario' WHERE id='$id'");
        }

        if (!empty($data_ncto)) {
            mysqli_query($mysqli, "UPDATE tb_funcionario SET data_ncto='$data_ncto' WHERE id='$id'");
        }

        if (!empty($nome)) {
            mysqli_query($mysqli, "UPDATE tb_funcionario SET nome='$nome' WHERE id='$id'");
        } 


        // Fecha a conexão com o banco de dados
        mysqli_close($mysqli);
    } else {
        echo "ID inválido.";
    }
}
?>

<a href="index.html">Home</a>
</body>
</html>